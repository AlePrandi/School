package serializzazioneJSON;

import originali.Libreria;
import originali.Libro;

import java.io.FileWriter;
import java.io.IOException;
import java.util.Vector;

public class LibreriaJSON extends Libreria {
    public LibreriaJSON() {
        super();
    }
    
    public boolean SalvaSuFile(String nomefile) throws IOException {
        boolean stato=false;
        FileWriter fw = new FileWriter(nomefile);
        fw.write("{\n");
        fw.write("\"Costo pagina fisso\": "+Libro.getCostoPagina()+"\n");
        fw.write("\"Libri\":[" + "\n");
        for(int k=0;k<libri.size();k++){
            fw.write("{ \n");
            fw.write("\"Autore\": "+libri.get(k).getAutore()+ "\n" + "\"Titolo\": "+ libri.get(k).getTitolo()+"\n"+ "\"Numero pagine\": " + libri.get(k).getNumeroPagine() + "\n");
            fw.write("}\n");
        }
        fw.write("]\n");
        fw.write("}");
        fw.close();
        return stato;
    }

    @Override
    public String toString() {
        return "Libreria = " + libri + " valore = " + getValoreTot();
    }


}